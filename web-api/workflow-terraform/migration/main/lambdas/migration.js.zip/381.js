"use strict";
exports.id = 381;
exports.ids = [381];
exports.modules = {

/***/ 33381:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  ENV_CREDENTIAL_SCOPE: () => (/* reexport */ ENV_CREDENTIAL_SCOPE),
  ENV_EXPIRATION: () => (/* reexport */ ENV_EXPIRATION),
  ENV_KEY: () => (/* reexport */ ENV_KEY),
  ENV_SECRET: () => (/* reexport */ ENV_SECRET),
  ENV_SESSION: () => (/* reexport */ ENV_SESSION),
  fromEnv: () => (/* reexport */ fromEnv)
});

// EXTERNAL MODULE: ./node_modules/@smithy/property-provider/dist-es/index.js + 6 modules
var dist_es = __webpack_require__(18112);
;// CONCATENATED MODULE: ./node_modules/@aws-sdk/credential-provider-node/node_modules/@aws-sdk/credential-provider-env/dist-es/fromEnv.js

const ENV_KEY = "AWS_ACCESS_KEY_ID";
const ENV_SECRET = "AWS_SECRET_ACCESS_KEY";
const ENV_SESSION = "AWS_SESSION_TOKEN";
const ENV_EXPIRATION = "AWS_CREDENTIAL_EXPIRATION";
const ENV_CREDENTIAL_SCOPE = "AWS_CREDENTIAL_SCOPE";
const fromEnv = (init) => async () => {
    init?.logger?.debug("@aws-sdk/credential-provider-env", "fromEnv");
    const accessKeyId = process.env[ENV_KEY];
    const secretAccessKey = process.env[ENV_SECRET];
    const sessionToken = process.env[ENV_SESSION];
    const expiry = process.env[ENV_EXPIRATION];
    const credentialScope = process.env[ENV_CREDENTIAL_SCOPE];
    if (accessKeyId && secretAccessKey) {
        return {
            accessKeyId,
            secretAccessKey,
            ...(sessionToken && { sessionToken }),
            ...(expiry && { expiration: new Date(expiry) }),
            ...(credentialScope && { credentialScope }),
        };
    }
    throw new dist_es/* CredentialsProviderError */.C1("Unable to find environment variable credentials.");
};

;// CONCATENATED MODULE: ./node_modules/@aws-sdk/credential-provider-node/node_modules/@aws-sdk/credential-provider-env/dist-es/index.js



/***/ })

};
;