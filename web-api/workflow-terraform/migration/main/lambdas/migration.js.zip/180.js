"use strict";
exports.id = 180;
exports.ids = [180];
exports.modules = {

/***/ 43180:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  fromIni: () => (/* reexport */ fromIni)
});

// EXTERNAL MODULE: ./node_modules/@smithy/shared-ini-file-loader/dist-es/index.js + 14 modules
var dist_es = __webpack_require__(3054);
// EXTERNAL MODULE: ./node_modules/@smithy/property-provider/dist-es/index.js + 6 modules
var property_provider_dist_es = __webpack_require__(18112);
;// CONCATENATED MODULE: ./node_modules/@aws-sdk/credential-provider-node/node_modules/@aws-sdk/credential-provider-ini/dist-es/resolveCredentialSource.js

const resolveCredentialSource = (credentialSource, profileName) => {
    const sourceProvidersMap = {
        EcsContainer: (options) => __webpack_require__.e(/* import() */ 897).then(__webpack_require__.bind(__webpack_require__, 47897)).then(({ fromContainerMetadata }) => fromContainerMetadata(options)),
        Ec2InstanceMetadata: (options) => __webpack_require__.e(/* import() */ 897).then(__webpack_require__.bind(__webpack_require__, 47897)).then(({ fromInstanceMetadata }) => fromInstanceMetadata(options)),
        Environment: (options) => __webpack_require__.e(/* import() */ 381).then(__webpack_require__.bind(__webpack_require__, 33381)).then(({ fromEnv }) => fromEnv(options)),
    };
    if (credentialSource in sourceProvidersMap) {
        return sourceProvidersMap[credentialSource];
    }
    else {
        throw new property_provider_dist_es/* CredentialsProviderError */.C1(`Unsupported credential source in profile ${profileName}. Got ${credentialSource}, ` +
            `expected EcsContainer or Ec2InstanceMetadata or Environment.`);
    }
};

;// CONCATENATED MODULE: ./node_modules/@aws-sdk/credential-provider-node/node_modules/@aws-sdk/credential-provider-ini/dist-es/resolveAssumeRoleCredentials.js




const isAssumeRoleProfile = (arg) => Boolean(arg) &&
    typeof arg === "object" &&
    typeof arg.role_arn === "string" &&
    ["undefined", "string"].indexOf(typeof arg.role_session_name) > -1 &&
    ["undefined", "string"].indexOf(typeof arg.external_id) > -1 &&
    ["undefined", "string"].indexOf(typeof arg.mfa_serial) > -1 &&
    (isAssumeRoleWithSourceProfile(arg) || isAssumeRoleWithProviderProfile(arg));
const isAssumeRoleWithSourceProfile = (arg) => typeof arg.source_profile === "string" && typeof arg.credential_source === "undefined";
const isAssumeRoleWithProviderProfile = (arg) => typeof arg.credential_source === "string" && typeof arg.source_profile === "undefined";
const resolveAssumeRoleCredentials = async (profileName, profiles, options, visitedProfiles = {}) => {
    options.logger?.debug("@aws-sdk/credential-provider-ini", "resolveAssumeRoleCredentials (STS)");
    const data = profiles[profileName];
    if (!options.roleAssumer) {
        const { getDefaultRoleAssumer } = await Promise.all(/* import() */[__webpack_require__.e(930), __webpack_require__.e(203)]).then(__webpack_require__.bind(__webpack_require__, 46203));
        options.roleAssumer = getDefaultRoleAssumer({
            ...options.clientConfig,
            credentialProviderLogger: options.logger,
            parentClientConfig: options?.parentClientConfig,
        }, options.clientPlugins);
    }
    const { source_profile } = data;
    if (source_profile && source_profile in visitedProfiles) {
        throw new property_provider_dist_es/* CredentialsProviderError */.C1(`Detected a cycle attempting to resolve credentials for profile` +
            ` ${(0,dist_es/* getProfileName */.Bz)(options)}. Profiles visited: ` +
            Object.keys(visitedProfiles).join(", "), false);
    }
    const sourceCredsProvider = source_profile
        ? resolveProfileData(source_profile, profiles, options, {
            ...visitedProfiles,
            [source_profile]: true,
        })
        : (await resolveCredentialSource(data.credential_source, profileName)(options))();
    const params = {
        RoleArn: data.role_arn,
        RoleSessionName: data.role_session_name || `aws-sdk-js-${Date.now()}`,
        ExternalId: data.external_id,
        DurationSeconds: parseInt(data.duration_seconds || "3600", 10),
    };
    const { mfa_serial } = data;
    if (mfa_serial) {
        if (!options.mfaCodeProvider) {
            throw new property_provider_dist_es/* CredentialsProviderError */.C1(`Profile ${profileName} requires multi-factor authentication, but no MFA code callback was provided.`, false);
        }
        params.SerialNumber = mfa_serial;
        params.TokenCode = await options.mfaCodeProvider(mfa_serial);
    }
    const sourceCreds = await sourceCredsProvider;
    return options.roleAssumer(sourceCreds, params);
};

;// CONCATENATED MODULE: ./node_modules/@aws-sdk/credential-provider-node/node_modules/@aws-sdk/credential-provider-ini/dist-es/resolveProcessCredentials.js
const isProcessProfile = (arg) => Boolean(arg) && typeof arg === "object" && typeof arg.credential_process === "string";
const resolveProcessCredentials = async (options, profile) => __webpack_require__.e(/* import() */ 496).then(__webpack_require__.bind(__webpack_require__, 37496)).then(({ fromProcess }) => fromProcess({
    ...options,
    profile,
})());

;// CONCATENATED MODULE: ./node_modules/@aws-sdk/credential-provider-node/node_modules/@aws-sdk/credential-provider-ini/dist-es/resolveSsoCredentials.js
const resolveSsoCredentials = async (profile, options = {}) => {
    const { fromSSO } = await __webpack_require__.e(/* import() */ 70).then(__webpack_require__.bind(__webpack_require__, 32070));
    return fromSSO({
        profile,
        logger: options.logger,
    })();
};
const isSsoProfile = (arg) => arg &&
    (typeof arg.sso_start_url === "string" ||
        typeof arg.sso_account_id === "string" ||
        typeof arg.sso_session === "string" ||
        typeof arg.sso_region === "string" ||
        typeof arg.sso_role_name === "string");

;// CONCATENATED MODULE: ./node_modules/@aws-sdk/credential-provider-node/node_modules/@aws-sdk/credential-provider-ini/dist-es/resolveStaticCredentials.js
const isStaticCredsProfile = (arg) => Boolean(arg) &&
    typeof arg === "object" &&
    typeof arg.aws_access_key_id === "string" &&
    typeof arg.aws_secret_access_key === "string" &&
    ["undefined", "string"].indexOf(typeof arg.aws_session_token) > -1;
const resolveStaticCredentials = (profile, options) => {
    options?.logger?.debug("@aws-sdk/credential-provider-ini", "resolveStaticCredentials");
    return Promise.resolve({
        accessKeyId: profile.aws_access_key_id,
        secretAccessKey: profile.aws_secret_access_key,
        sessionToken: profile.aws_session_token,
        credentialScope: profile.aws_credential_scope,
    });
};

;// CONCATENATED MODULE: ./node_modules/@aws-sdk/credential-provider-node/node_modules/@aws-sdk/credential-provider-ini/dist-es/resolveWebIdentityCredentials.js
const isWebIdentityProfile = (arg) => Boolean(arg) &&
    typeof arg === "object" &&
    typeof arg.web_identity_token_file === "string" &&
    typeof arg.role_arn === "string" &&
    ["undefined", "string"].indexOf(typeof arg.role_session_name) > -1;
const resolveWebIdentityCredentials = async (profile, options) => __webpack_require__.e(/* import() */ 380).then(__webpack_require__.bind(__webpack_require__, 23380)).then(({ fromTokenFile }) => fromTokenFile({
    webIdentityTokenFile: profile.web_identity_token_file,
    roleArn: profile.role_arn,
    roleSessionName: profile.role_session_name,
    roleAssumerWithWebIdentity: options.roleAssumerWithWebIdentity,
    logger: options.logger,
    parentClientConfig: options.parentClientConfig,
})());

;// CONCATENATED MODULE: ./node_modules/@aws-sdk/credential-provider-node/node_modules/@aws-sdk/credential-provider-ini/dist-es/resolveProfileData.js






const resolveProfileData = async (profileName, profiles, options, visitedProfiles = {}) => {
    const data = profiles[profileName];
    if (Object.keys(visitedProfiles).length > 0 && isStaticCredsProfile(data)) {
        return resolveStaticCredentials(data, options);
    }
    if (isAssumeRoleProfile(data)) {
        return resolveAssumeRoleCredentials(profileName, profiles, options, visitedProfiles);
    }
    if (isStaticCredsProfile(data)) {
        return resolveStaticCredentials(data, options);
    }
    if (isWebIdentityProfile(data)) {
        return resolveWebIdentityCredentials(data, options);
    }
    if (isProcessProfile(data)) {
        return resolveProcessCredentials(options, profileName);
    }
    if (isSsoProfile(data)) {
        return await resolveSsoCredentials(profileName, options);
    }
    throw new property_provider_dist_es/* CredentialsProviderError */.C1(`Profile ${profileName} could not be found or parsed in shared credentials file.`);
};

;// CONCATENATED MODULE: ./node_modules/@aws-sdk/credential-provider-node/node_modules/@aws-sdk/credential-provider-ini/dist-es/fromIni.js


const fromIni = (init = {}) => async () => {
    init.logger?.debug("@aws-sdk/credential-provider-ini", "fromIni");
    const profiles = await (0,dist_es/* parseKnownFiles */.YU)(init);
    return resolveProfileData((0,dist_es/* getProfileName */.Bz)(init), profiles, init);
};

;// CONCATENATED MODULE: ./node_modules/@aws-sdk/credential-provider-node/node_modules/@aws-sdk/credential-provider-ini/dist-es/index.js



/***/ })

};
;