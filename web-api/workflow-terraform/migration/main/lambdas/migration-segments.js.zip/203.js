"use strict";
exports.id = 203;
exports.ids = [203];
exports.modules = {

/***/ 46203:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getDefaultRoleAssumer: () => (/* reexport safe */ _aws_sdk_client_sts__WEBPACK_IMPORTED_MODULE_0__.cz)
/* harmony export */ });
/* harmony import */ var _aws_sdk_client_sts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(76930);




/***/ })

};
;