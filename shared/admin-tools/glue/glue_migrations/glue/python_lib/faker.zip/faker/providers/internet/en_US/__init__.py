from .. import Provider as InternetProvider


class Provider(InternetProvider):
    pass
